/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { JobSearch } from './components/JobSearch';
import { EssentialAddresses } from './components/EssentialAddresses';
import { MapSection } from './components/MapSection';
import { ApplicationsSection } from './components/ApplicationsSection';
import { SettingsProfile } from './components/SettingsProfile';
import { CVBuilder } from './components/CVBuilder';
import { AdminPanel } from './components/AdminPanel';
import { AuthModal } from './components/AuthModal';
import {
  CheckCircle2,
  AlertCircle,
  Info,
  Briefcase,
  Lock,
  ShieldCheck,
} from 'lucide-react';
import { AdminQuickToolbar } from './components/AdminQuickToolbar';
import { AboutUsModal } from './components/AboutUsModal';
import { PostJobSection } from './components/PostJobSection';
import { AboutUsSection } from './components/AboutUsSection';
import { OnboardingFlow } from './components/OnboardingFlow';
import { PartnerSection } from './components/PartnerSection';

const MainContent: React.FC = () => {
  const { activeTab, setActiveTab, isAdminLoggedIn, toasts, hasCompletedOnboarding } = useApp();
  const [adminLoginModalOpen, setAdminLoginModalOpen] = useState(false);
  const [aboutUsModalOpen, setAboutUsModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Onboarding Flow overlay on first launch */}
      {!hasCompletedOnboarding && <OnboardingFlow />}
      {/* Dynamic Top Theme Color Bar (Changes with selected theme color) */}
      <div style={{ background: 'var(--primary-topbar)' }} className="h-1 w-full shrink-0 shadow-xs transition-all duration-300" />

      {/* Floating Omnipresent Admin Quick Toolbar (When Admin Logged In) */}
      <AdminQuickToolbar />

      {/* PWA Install Banner & Offline bar */}
      <PWAInstallBanner />

      {/* Main App Navigation Header */}
      <Header />

      {/* Main Page Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 lg:pb-12">
        {activeTab === 'jobs' && <JobSearch />}
        {activeTab === 'post-job' && <PostJobSection />}
        {activeTab === 'partner' && <PartnerSection />}
        {activeTab === 'about-us' && <AboutUsSection />}
        {activeTab === 'map' && <MapSection />}
        {activeTab === 'addresses' && <EssentialAddresses />}
        {activeTab === 'my-applications' && <ApplicationsSection />}
        {activeTab === 'settings' && <SettingsProfile />}
        {activeTab === 'cv-builder' && <CVBuilder />}
        {activeTab === 'admin' && (
          isAdminLoggedIn ? (
            <AdminPanel />
          ) : (
            <div className="max-w-md mx-auto py-16 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto">
                <Lock className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold">بخش اختصاصی مدیران کارباما</h2>
              <p className="text-xs text-slate-400">
                این بخش فقط با ورود نام کاربری و رمز عبور مدیر سامانه قابل دسترسی است.
              </p>
              <button
                onClick={() => setAdminLoginModalOpen(true)}
                className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs shadow-md transition"
              >
                ورود به بخش مدیریت (نام کاربری و رمز)
              </button>
            </div>
          )
        )}
      </main>

      {/* Footer (Desktop & Universal) */}
      <footer className="bg-white/80 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 py-4 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-right">
            <div className="flex items-center gap-3">
              <img
                src="/logo.png"
                alt="لوگوی کارباما"
                className="w-7 h-7 rounded-full object-cover border border-amber-400/50 shadow-sm"
              />
              <span className="font-bold text-slate-800 dark:text-white">
                کارباما (KARBAMA) | سامانه کاریابی و اقامت ایرانیان در ترکیه
              </span>
              <span className="hidden sm:inline text-slate-400">|</span>
              <span className="hidden sm:inline text-slate-500">پشتیبانی آفلاین PWA و اندروید</span>
            </div>

            <div className="flex items-center gap-4 text-[11px]">
              <span className="hidden md:inline">شماره‌های ضروری: ۱۵۷ (اقامت) - ۱۷۰ (وزارت کار) - ۱۱۲ (اورژانس)</span>
              
              {/* About Us Link */}
              <button
                onClick={() => setAboutUsModalOpen(true)}
                className="text-amber-500 dark:text-amber-400 font-bold hover:underline flex items-center gap-1 transition"
              >
                <Info className="w-3.5 h-3.5" />
                درباره ما
              </button>

              {/* Discreet Admin Login Trigger when not logged in */}
              {!isAdminLoggedIn ? (
                <button
                  onClick={() => setAdminLoginModalOpen(true)}
                  className="text-slate-400 dark:text-slate-500 hover:text-amber-400 flex items-center gap-1 transition"
                  title="ورود با دسترسی مدیریت (یوزرنیم و پسوورد)"
                >
                  <Lock className="w-3 h-3" />
                  ورود مدیر
                </button>
              ) : (
                <span className="text-amber-400 flex items-center gap-1 font-bold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  مدیریت فعال
                </span>
              )}
            </div>
          </div>

          {/* User Requested Universal Faint Footer Attribution */}
          <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center justify-center">
            <p className="text-[11px] font-mono tracking-wide text-slate-400/70 dark:text-slate-500/70 select-none text-center">
              powered by Naser Tavakkoli . @Ntgalaxy
            </p>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav />

      {/* Floating Toast Notification Container */}
      <div className="fixed bottom-20 lg:bottom-6 left-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-2xl border text-xs font-medium animate-in fade-in slide-in-from-bottom-3 duration-300 ${
              toast.type === 'success'
                ? 'bg-slate-900 border-emerald-500/50 text-emerald-200'
                : toast.type === 'error'
                ? 'bg-slate-900 border-red-500/50 text-red-200'
                : 'bg-slate-900 border-slate-700 text-slate-200'
            }`}
          >
            {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
            {toast.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{toast.message}</span>
          </div>
        ))}
      </div>

      {/* Admin Login Modal */}
      <AuthModal
        isOpen={adminLoginModalOpen}
        onClose={() => setAdminLoginModalOpen(false)}
        defaultMode="admin"
      />

      {/* About Us Modal */}
      <AboutUsModal
        isOpen={aboutUsModalOpen}
        onClose={() => setAboutUsModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
