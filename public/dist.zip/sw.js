/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "0de0dd9b6f4c623acee99aa088e8fc36"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e219671eca15cbe35c41bff1f22ad778"
  }, {
    "url": "pwa-192x192.png",
    "revision": "061fef2fc501c242caf7525341a048a9"
  }, {
    "url": "pwa-1024x1024.png",
    "revision": "873ef561a9e9644e0daae38865b3892a"
  }, {
    "url": "logo.png",
    "revision": "c22a9fc848dfc034d4f2a28defe2cfa8"
  }, {
    "url": "index.html",
    "revision": "f638560dd76ae6ab9c04c1b7d71cf371"
  }, {
    "url": "icon.svg",
    "revision": "0fca2080c18fa7cd35ac70e5b0263ea0"
  }, {
    "url": "favicon.ico",
    "revision": "3438f406e9e9e9e4894fb08c1d2127bb"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "3c0b7d2568b33ee215e14254f5cb239b"
  }, {
    "url": "assets/index-D3JO73rI.js",
    "revision": null
  }, {
    "url": "assets/index-BnnPnvge.css",
    "revision": null
  }, {
    "url": "assets/aistudio/IMG_20261024_100515_1058bd9b.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "3c0b7d2568b33ee215e14254f5cb239b"
  }, {
    "url": "favicon.ico",
    "revision": "3438f406e9e9e9e4894fb08c1d2127bb"
  }, {
    "url": "icon.svg",
    "revision": "0fca2080c18fa7cd35ac70e5b0263ea0"
  }, {
    "url": "pwa-1024x1024.png",
    "revision": "873ef561a9e9644e0daae38865b3892a"
  }, {
    "url": "pwa-192x192.png",
    "revision": "061fef2fc501c242caf7525341a048a9"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e219671eca15cbe35c41bff1f22ad778"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0de0dd9b6f4c623acee99aa088e8fc36"
  }, {
    "url": "manifest.webmanifest",
    "revision": "867277048869012dea65af870289ee44"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
